import { Card, CardContent } from @componentsuicard;
import { Button } from @componentsuibutton;
import { Textarea } from @componentsuitextarea;
import { Dialog, DialogContent } from @componentsuidialog;
import { useEffect, useState } from react;

export default function AstronautDashboard() {
  const [checklist, setChecklist] = useState(() = {
    const saved = localStorage.getItem(astroChecklist);
    return saved  JSON.parse(saved)  {
      warmUp false,
      crunchMachine false,
      legPress false,
      chestPress false,
      latPulldown false,
      cardio false,
      cooldown false,
    };
  });

  const [notes, setNotes] = useState(() = localStorage.getItem(astroNotes)  );
  const [date, setDate] = useState(new Date().toLocaleDateString());
  const [showHowTo, setShowHowTo] = useState(() = !localStorage.getItem(seenHowTo));

  useEffect(() = {
    localStorage.setItem(astroChecklist, JSON.stringify(checklist));
    localStorage.setItem(astroNotes, notes);
  }, [checklist, notes]);

  const handleCloseHowTo = () = {
    setShowHowTo(false);
    localStorage.setItem(seenHowTo, true);
  };

  const toggleCheck = (key) = {
    setChecklist((prev) = ({ ...prev, [key] !prev[key] }));
  };

  const totalTasks = Object.keys(checklist).length;
  const completedTasks = Object.values(checklist).filter(Boolean).length;
  const progress = Math.round((completedTasks  totalTasks)  100);

  const getRank = () = {
    if (progress === 100) return 🧑‍🚀 Space Ace;
    if (progress = 75) return 🚀 Rocket Rookie;
    if (progress = 50) return 🌟 Core Cadet;
    if (progress = 25) return 🛰️ Mission Starter;
    return 👨‍💻 Trainee;
  };

  const quotes = [
    One plank for man, one giant gain for mankind.,
    Your mission is training, your reward is orbit.,
    Even astronauts start with wall push-ups.,
    Failure is not an option—rest days are!,
    The gym is your launchpad.
  ];
  const dailyQuote = quotes[new Date().getDate() % quotes.length];

  return (
    div className=p-4 grid gap-6 min-h-screen bg-zinc-900 text-white
      h1 className=text-3xl font-bold text-center🚀 Astronaut Training Dashboardh1

      p className=text-center text-sm text-zinc-400📅 {date}p
      p className=text-center italic text-zinc-300🧠 {dailyQuote}p

      Card className=bg-zinc-800 rounded-2xl shadow-lg
        CardContent className=p-6 grid gap-4
          h2 className=text-xl font-semibold📝 Today's Mission Checklisth2
          {Object.entries({
            warmUp Warm-Up Light walk & stretches,
            crunchMachine Ab Crunch Machine (2-3 sets),
            legPress Leg Press or Leg Curl (2-3 sets),
            chestPress Chest Press (2-3 sets),
            latPulldown Lat Pulldown (2-3 sets),
            cardio Treadmill walkjog or intervals,
            cooldown Cooldown Stretch + Water
          }).map(([key, label]) = (
            Button
              key={key}
              onClick={() = toggleCheck(key)}
              className={`w-full justify-start text-left py-3 px-4 rounded-xl text-base font-medium transition-colors duration-200 ${checklist[key]  'bg-green-600 text-white hoverbg-green-500'  'bg-zinc-700 text-white hoverbg-zinc-600'}`}
            
              {checklist[key]  ✅  ⬜} {label}
            Button
          ))}
          div className=mt-4 text-center
            p className=text-lg📊 Progress {progress}%p
            p className=text-lg🎖️ Rank {getRank()}p
          div

          div className=mt-6
            h3 className=text-md font-semibold mb-2🪐 Daily Log  Reflectionsh3
            Textarea
              value={notes}
              onChange={(e) = setNotes(e.target.value)}
              placeholder=Write about your workout today...
              className=bg-zinc-700 text-white p-3 rounded-xl
            
          div

          div className=mt-6 text-center
            a
              href=httpsforms.gleYOUR_FORM_LINK  replace with your actual feedback form
              target=_blank
              rel=noopener noreferrer
              className=text-sm text-blue-400 underline hovertext-blue-300
            
              🛠️ Send Feedback
            a
          div
        CardContent
      Card

      {showHowTo && (
        Dialog open={showHowTo} onOpenChange={handleCloseHowTo}
          DialogContent className=bg-zinc-800 text-white p-6 rounded-xl max-w-md mx-auto
            h2 className=text-xl font-bold mb-2👨‍🚀 How to Useh2
            ul className=list-disc pl-5 space-y-2
              liTap each task to check it off as you complete it.li
              liYour progress and notes are saved automatically.li
              liReview your rank and motivation quote daily!li
              liAdd any thoughts or reflections in the log box.li
              liUse the feedback link to share ideas or issues!li
            ul
            div className=text-right mt-4
              Button onClick={handleCloseHowTo}Got it!Button
            div
          DialogContent
        Dialog
      )}
    div
  );
}
